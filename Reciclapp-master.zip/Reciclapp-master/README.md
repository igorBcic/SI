# Reciclapp
A web page to help who wants to recycle things.

***Para rodar o código:***<br>

- Primeiro tenha em sua máquina o Wampserver64 ou o Xampp, que são pacotes com os principais servidores de código aberto do mercado, incluindo FTP, banco de dados MySQL, Apache e etc.
- Clone o repositório em:<br>
    **Wampserver64**: C:\wamp64\www<br>
    **Xampp**: C:\xamp\htdocs<br>
- Dê start no Apache se estiver usando o xampp<br>
- Apenas abra o Wampserver64 se estiver usando o mesmo<br>
- No navegador abra http://localhost/reciclapp/index.html


-Para acessar o banco, use http://localhost/phpmyadmin , crie o banco usando os comandos no arquivo banco.sql.
(OBS: certifique-se de que seu usuário root esteja sem senha para poder logar no phpmyadmin e pro projeto funcionar também).

![VPKIv0jF6f](https://user-images.githubusercontent.com/48591119/134830667-5aae5234-ab5e-4218-96c2-57c73e74386f.gif)

